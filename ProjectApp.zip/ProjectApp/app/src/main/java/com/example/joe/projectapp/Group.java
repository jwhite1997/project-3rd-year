package com.example.joe.projectapp;

public class Group {


    private String groupID;
    private String gName;
    private String type;
    private String status;
    private String houseID;

    public Group(){}

    public Group(String groupID, String gName, String type,String status, String houseID) {
        this.groupID = groupID;
        this.gName = gName;
        this.type = type;
        this.status= status;
        this.houseID = houseID;
    }


    public String getGroupID() {
        return groupID;
    }

    public String getGName() {
        return gName;
    }

    public String getType() {
        return type;
    }

    public String getStatus(){
        return status;
    }

    public String getHouseID() {
        return houseID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    public void setGName(String gNmae) {
        this.gName = gNmae;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setHouseID(String houseID) {
        this.houseID = houseID;
    }
}
