package com.example.joe.projectapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;



public class FragmentHue extends Fragment {

    View v;

    private RecyclerView myrecyclerview;
    private List<Group> lstGroup;


    public FragmentHue(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle saveInstanceState){
        v = inflater.inflate(R.layout.hue_fragment,container,false);
        myrecyclerview = (RecyclerView) v.findViewById(R.id.group_recyclerview);
        RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(),lstGroup);
        myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        myrecyclerview.setAdapter(recyclerAdapter);
        return v;
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //gonna need to get all lightGroups here
        lstGroup = new ArrayList<>();
        //cant be hard coded
        lstGroup.add(new Group("0","Kitchen","LightGroup","on","1"));
        lstGroup.add(new Group("1", "Bedroom1","on","LightGroup","1"));
        lstGroup.add(new Group("2","FrontRoom","off","LightGroup","1"));

    }



}
