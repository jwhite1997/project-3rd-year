package com.epmmu.mqttdemo;

import android.app.Activity;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MainActivity extends Activity {

    TextView sensorValueTV;
    public static final String BROKER_URL = "tcp://iot.eclipse.org:1883";

    //We have to generate a unique Client id.
    //    String clientId = Utils.getMacAddress() + "-sub";
    String clientId = "Billy_No_Mates";
    private MqttClient mqttClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // temp use of ThreadPolicy until use AsyncTask
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        sensorValueTV = (TextView) findViewById(R.id.sensorValueTV);

        // Create MQTT client and start subscribing to message queue
        try {
            // change from original. Messages in "null" are not stored
            mqttClient = new MqttClient(BROKER_URL, clientId,null);
            mqttClient.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectionLost(Throwable cause) {
                    //This is called when the connection is lost. We could reconnect here.
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    System.out.println("Message arrived. Topic: " + topic + "  Message: " + message.toString());
                    // get message data and strip of trailing character
                    final String messageStr = message.toString();
                    final TextView sensorValueTV = (TextView) findViewById(R.id.sensorValueTV);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            // Update UI elements
                            sensorValueTV.setText(messageStr);
                        }
                    });
                    if ("mmusensor/LWT".equals(topic)) {
                        System.err.println("Sensor gone!");
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    //no-op
                }

                @Override
                public void connectComplete(boolean b , String s) {
                    //no-op
                }
            });
            } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }


        startSubscribing();

    }

    public void startSubscribing() {
        try {
            mqttClient.connect();

            //Subscribe to all subtopics of home
            final String topic = "mmusensor/slider";
            mqttClient.subscribe(topic);

            System.out.println("Subscriber is now listening to "+topic);
            sensorValueTV.setText("Listening");

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
