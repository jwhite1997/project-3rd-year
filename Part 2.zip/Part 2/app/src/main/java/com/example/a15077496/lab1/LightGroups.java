package com.example.a15077496.lab1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import lights.HueDAO;
import lights.Lights;

public class LightGroups extends AppCompatActivity{

    private LinearLayout linearLayout;
    private int i;
    ArrayList<Lights> arrLight;
    AlertDialog alertDialog;

    // Creates a new activity

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.dialog_group);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Intent intent = getIntent();
        int id = intent.getIntExtra("id", 0);
        System.out.println("GroupID: "+ id);
        linearLayout = (LinearLayout) findViewById( R.id.groupsLayout );

        // Create an alert dialog for displaying errors
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        if(id==0) {
            // Shouldn't happen unless there's a server issue.

            alertDialog.setMessage( "Something went wrong! Try logging out and back in again.\n" +
                    " If this error continues, please contact an administrator." );
        }
        else
        {
            // Fills the array with all lights in that group
            arrLight = getLightsByGroup(id);

            if(arrLight.size() > 0)
            {
                for(i=0;i<arrLight.size();i++)
                {
                    TextView name = new TextView( this );
                    TextView status = new TextView( this );

                    name.setText( "Device number: " + arrLight.get( i ).getId() );
                    if(arrLight.get( i ).getOn().matches( "1" ))
                    {
                        status.setText( "Status: On" );
                    }
                    else
                    {
                        status.setText( "Status: Off" );
                    }

                    linearLayout.addView( name );

                    linearLayout.addView( status );

                }
            }
            else
            {
                // No lights attached to the group.
                TextView name = new TextView( this );
                name.setText( "You have no lights!" );
                linearLayout.addView( name );

            }
        }

    }


    public ArrayList<Lights> getLightsByGroup(int id)
    {

        ArrayList<Lights> arrayList = null;

        HueDAO hueDAO = new HueDAO();

        arrayList = hueDAO.findAllByGroup( id );

        return arrayList;



    }
}
