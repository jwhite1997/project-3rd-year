package com.example.a15077496.lab1;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import group.Group;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    Context mContext;
    List<Group> mData;
    Dialog myDialog;

    public RecyclerViewAdapter(Context mContext,List<Group> mData){
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v;
        v = LayoutInflater.from(mContext).inflate(R.layout.item_hue,parent,false);
        final MyViewHolder vHolder = new MyViewHolder(v);

        myDialog = new Dialog(mContext);
        myDialog.setContentView(R.layout.dialog_hue);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        vHolder.item_hue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                TextView dialog_name_tv =(TextView) myDialog.findViewById(R.id.dialog_name_id);
                TextView dialog_type_tv =(TextView) myDialog.findViewById(R.id.dialog_type_id);
                TextView dialog_status_tv =(TextView) myDialog.findViewById(R.id.dialog_status_id);
                dialog_name_tv.setText(mData.get(vHolder.getAdapterPosition()).getgName());
                dialog_type_tv.setText(mData.get(vHolder.getAdapterPosition()).getType());
                dialog_status_tv.setText(mData.get(vHolder.getAdapterPosition()).getStatus());
                Toast.makeText(mContext, "Clicked" + String.valueOf(vHolder.getAdapterPosition()), Toast.LENGTH_SHORT).show();
                myDialog.show();
            }
        });

        return vHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tv_name.setText(mData.get(position).getgName());
        holder.tv_type.setText(mData.get(position).getType());
        holder.tv_status.setText(mData.get(position).getStatus());

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        private LinearLayout item_hue;
        private TextView tv_name;
        private TextView tv_type;
        private TextView tv_status;





        public MyViewHolder(View itemView){
            super(itemView);
            item_hue = (LinearLayout) itemView.findViewById(R.id.group_item_id);
            tv_name = (TextView) itemView.findViewById(R.id.name_group);
            tv_type = (TextView) itemView.findViewById(R.id.light_type);
            tv_status = (TextView) itemView.findViewById(R.id.light_status);
        }


    }
}