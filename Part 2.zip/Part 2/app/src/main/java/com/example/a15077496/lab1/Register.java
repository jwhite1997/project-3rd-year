package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.UUID;

public class Register extends AppCompatActivity {

    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // take username and password


        Button btnRegister = (Button) findViewById(R.id.btnRegister);
        final AlertDialog alertDialog = new AlertDialog.Builder(Register.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TextView userIn = (EditText) findViewById(R.id.userIn);
                TextView passIn = (EditText) findViewById(R.id.passIn);
                String username = userIn.getText().toString();
                String password = passIn.getText().toString();

                // Creates a random UUID (128-bit identifier)
                String houseID = UUID.randomUUID().toString();

                // Encodes password
                String passEnc = new String( Hex.encodeHex(DigestUtils.sha256(
                        password )));

                int code = toServer(username, passEnc, houseID);

                // Switch on HTTP status code

                switch(code)
                {
                    case 200:

                        alertDialog.setMessage("Account created. Redirecting to login screen.");
                        alertDialog.show();

                        alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialogInterface) {

                                // Redirects to login after register
                                Intent myIntent = new Intent(Register.this, Login.class);
                                Register.this.startActivity(myIntent);

                            }
                        });

                        break;
                    case 401:

                        alertDialog.setMessage("User already exists! Try logining in instead.");
                        alertDialog.show();

                        break;
                    case 422:

                        alertDialog.setMessage("Please check that username and password are set.");
                        alertDialog.show();

                        break;
                    case 500:

                        alertDialog.setMessage("Server error. If this error continues, please contact" +
                                " an administrator.");
                        alertDialog.show();
                    case 503:
                        alertDialog.setMessage( "Server is offline! Please try again later" );
                        alertDialog.show();

                        break;
                    case 404:

                        alertDialog.setMessage("Server error. If this error continues, please contact" +
                                " an administrator.");
                        alertDialog.show();

                        break;

                }

            }




        });



    }
    public int toServer(String username, String password, String house)
    {
        URL url;
        HttpURLConnection conn;
        String serverURL = "http://10.0.2.2:8080/ProjectTesting/NewUser";

        String fullURL;

        fullURL = serverURL + "?" +"username=" + username + "&&password="+password+"&&houseID="+house;

        int result;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();


        } catch (Exception e) {
            e.printStackTrace();
            result = 503;
        }

        return result;
    }
}