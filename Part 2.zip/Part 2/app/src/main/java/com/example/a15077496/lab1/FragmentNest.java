package com.example.a15077496.lab1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import group.Group;
import user.User;

public class FragmentNest extends Fragment {

    View v;
    private String username;
    private String password;
    private String temp;
    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";

    private RecyclerView myrecyclerview;
    ArrayList<Group> all = new ArrayList<Group>();
    private List<Group> lstGroup=new ArrayList<>();
    public FragmentNest() {
    }
    AlertDialog alertDialog = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {

        alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });


        Bundle b = getArguments();
        if (b !=null) {
            // String username = bundle.getString("username");
            temp     = b.getString("temp");
            System.out.println("Current temp = "+ temp);
            username = b.getString("username");
            password = b.getString("password");
        }else{
            alertDialog.show();
        }

        v = inflater.inflate(R.layout.nest_fragment, container, false);



       //changeTemp(username, password,temp);

        User user = getUser(username, password);
        findDevices(user);



        myrecyclerview = (RecyclerView) v.findViewById(R.id.group_recyclerview_nest);
        RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(), lstGroup);
        myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        myrecyclerview.setAdapter(recyclerAdapter);

        return v;
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }

    public ArrayList<Group> getHouse(String houseID) {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL;

        fullURL = sensorServerURL + "GetAllByHouse?id=" + houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();
        ArrayList<Group> arrGroup = new ArrayList<>();
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                Group oneGroup = gson.fromJson(jsonArray.getString(i), Group.class);
                arrGroup.add(oneGroup);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrGroup;


    }

    //final ArrayList<Group> arrGroup = getHouse(user.getHouseID());
    public void findDevices(User user) {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());

        //LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearlayout_id);
        //setContentView(linearLayout);

        if (arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);



                if (!oneGroup.getgName().matches("Unattached")) {
                    // TextView textView = new TextView(this);
                    //textView.setText(oneGroup.toString());
                    //textView.setTextSize(30);
                    //linearLayout.addView(textView);


                    final int id = arrGroup.get(i).getGroupID();

                    if(!oneGroup.getType().matches("LightGroup")) {

                        int groupID = oneGroup.getGroupID();
                        arrGroup.get(i).setStatus(temp);
                        changeTemp(temp,groupID);

                        all.add( (arrGroup.get( i )));
                        // arrGroup.get(i).getGroupID().setStatus();
                        lstGroup.add( arrGroup.get( i ) );





                    }




                } else {

                    System.out.println("help me");
                }

            }
        }
    }


    public User getUser(String username, String password)
    {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ URLEncoder.encode("username="+username+"&&password="+password);

        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();
        User oneUser = null;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");


            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            if(conn.getResponseCode()==200) {
                JSONArray jsonArray = new JSONArray(result.toString());


                for (int i = 0; i < jsonArray.length(); i++) {
                    Gson gson = new Gson();
                    oneUser = gson.fromJson(jsonArray.getString(i), User.class);
                }
            }
            else
            {
                oneUser = null;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;


    }


    public void restart(){
        getFragmentManager().beginTransaction().detach(this).attach(this).commit();

    }


    public int changeTemp(String status, int groupID)
    {
        int result = 500;
        URL url;
        HttpURLConnection conn;

        String fullURL;

        fullURL = sensorServerURL + "ChangeTemp?id="+groupID+"&&status="+status;

        System.out.println(fullURL);

        try{
            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod( "POST" );

            result = conn.getResponseCode();


        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return result;

    }

    // method to send data to server
    public int sendToServer(int status, int groupID) {

        int result = 500;
        URL url;
        HttpURLConnection conn;
        if (status == 1) {
            // go to on servlet

            String fullURL;

            fullURL = sensorServerURL + "turnOn?id=" + groupID;

            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");

                result = conn.getResponseCode();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (status == 0) {
            // go to off servlet
            String fullURL;

            fullURL = sensorServerURL + "turnOff?id=" + groupID;


            fullURL = fullURL.replaceAll("%3D", "=")
                    .replaceAll("%26", "&")
                    // .replaceAll("%5B","[")
                    //.replaceAll("%5D","]")
                    .replaceAll("%2C", ",");

            System.out.println("FULLURL: " + fullURL);


            try {

                url = new URL(fullURL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");

                System.out.println("CODE: "+conn.getResponseCode());
                result = conn.getResponseCode();


            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("HELP");
            result = 500;
        }

        return result;

    }


}
