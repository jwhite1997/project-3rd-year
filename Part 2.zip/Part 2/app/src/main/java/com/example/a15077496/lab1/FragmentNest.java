package com.example.a15077496.lab1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import group.Group;
import user.User;

public class FragmentNest extends Fragment {

    View v;
    private String username;
    private String password;
    private String temp="";
    // Localhost URL

    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";

    // Declare a new RecyclerView
    private RecyclerView myrecyclerview;
    ArrayList<Integer> all = new ArrayList<>();
    private List<Group> lstGroup=new ArrayList<>();
    public FragmentNest() {
    }
    AlertDialog alertDialog = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {


        // Clears variables and arrays
        username = "";
        password = "";
        temp ="";
        all.clear();
        lstGroup.clear();

        // Create an alert dialog for displaying errors
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });


        // Bring data into fragment from the main activity
        Bundle b = getArguments();
        if (b !=null) {

            username = b.getString("username");
            password = b.getString("password");
            temp     = b.getString( "temp" );

        }else{
            // Bundle hasn't set properly
            alertDialog.show();
        }

        v = inflater.inflate(R.layout.nest_fragment, container, false);


        User user = getUser(username, password);

        // If a user is returned...
        if(user!=null&& temp!=null)
        {

            findDevices(user,temp);

            // Activates the RecycleView for additional options

            myrecyclerview = (RecyclerView) v.findViewById(R.id.group_recyclerview_nest);
            RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(), lstGroup);
            myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
            myrecyclerview.setAdapter(recyclerAdapter);
        }else if (user!=null && temp==null){

            findDevicesNull(user);

            // Activates the RecycleView for additional options

            myrecyclerview = (RecyclerView) v.findViewById(R.id.group_recyclerview_nest);
            RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(), lstGroup);
            myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
            myrecyclerview.setAdapter(recyclerAdapter);
        }
        else
        {
            alertDialog.setMessage( "Something went wrong! Please logout and log back in again.\n" +
                    "If this error continues, please contact an administrator." );
        }


        return v;
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }

    public ArrayList<Group> getHouse(String houseID) {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL;

        fullURL = sensorServerURL + "GetAllByHouse?id=" + houseID;



        String line;
        StringBuilder result = new StringBuilder();
        ArrayList<Group> arrGroup = new ArrayList<>();
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            // Reads the data send back from the server

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            // Converts data from JSONArray to a user

            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                Group oneGroup = gson.fromJson(jsonArray.getString(i), Group.class);
                arrGroup.add(oneGroup);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrGroup;


    }

    public void findDevices(User user,String temp) {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());

        if (arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);

                // Groups check
                if(!temp.matches("")){
                    if (!oneGroup.getgName().matches("Unattached")) {


                        final int id = arrGroup.get( i ).getGroupID();

                        if (!oneGroup.getType().matches( "LightGroup" )) {

                            oneGroup.setStatus( temp );
                            all.add( (arrGroup.get( i )).getGroupID() );

                            lstGroup.add( arrGroup.get( i ) );

                        }

                    }else{
                            System.out.println("help me");
                        }


                    } else if (!oneGroup.getType().matches("LightGroup")&& temp=="")
                    {
                        all.add( (arrGroup.get( i )).getGroupID() );

                        lstGroup.add( arrGroup.get( i ) );
                    }else{
                    System.out.println("help me");
                }


            }
        }
    }

    public void findDevicesNull(User user) {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());

        if (arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);

                // Groups check

                    if (!oneGroup.getgName().matches("Unattached")) {


                        final int id = arrGroup.get( i ).getGroupID();

                        if (!oneGroup.getType().matches( "LightGroup" )) {

                            all.add( (arrGroup.get( i )).getGroupID() );

                            lstGroup.add( arrGroup.get( i ) );

                        }

                    }else{
                        System.out.println("help me");
                    }




            }
        }
    }


    public User getUser(String username, String password)
    {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ "username="+username+"&&password="+password;



        String line;
        StringBuilder result = new StringBuilder();
        User oneUser = null;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            // Reads the data send back from the server

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            // Alternative to a switch statement on the status code

            if(conn.getResponseCode()==200) {
                JSONArray jsonArray = new JSONArray(result.toString());


                for (int i = 0; i < jsonArray.length(); i++) {
                    Gson gson = new Gson();
                    oneUser = gson.fromJson(jsonArray.getString(i), User.class);
                }
            }
            else
            {
                oneUser = null;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;

    }


    public void restart(){
        getFragmentManager().beginTransaction().detach(this).attach(this).commit();

    }
}
