package com.example.a15077496.lab1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import group.Group;
import user.User;

public class FragmentHue extends Fragment {

    View v;
    private String username;
    User user;
    private String password;
    private int code;

    // Localhost URL

    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";

    // Declare a new RecyclerView
    private RecyclerView myrecyclerview;

    ArrayList<Integer> all = new ArrayList<>();
    private List<Group> lstGroup=new ArrayList<>();
    public FragmentHue() {
    }
    AlertDialog alertDialog = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {



        // Ensures the arrays are clear.
        all.clear();
        lstGroup.clear();

        // Create an alert dialog for displaying errors
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Server error. This may be due to a temporary outage. Please try again later.");
        alertDialog.setButton(android.support.v7.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });


        // Bring data into fragment from the main activity

        Bundle b = getArguments();
        if (b !=null) {

            username = b.getString("username");
            password = b.getString("password");

        }else{

            // Bundle didn't set properly
            alertDialog.show();
       }

        user = getUser(username, password);

        v = inflater.inflate(R.layout.hue_fragment, container, false);


        // HTTP Status code after checking the user.

        switch (code) {
            case 200:
                code = 500;

                findDevices( user );
                break;
            case 422:
                alertDialog.setMessage( "Uh oh, something went wrong! Try logging out and back in again." +
                        " If this error continues, please contact an administrator." );
                alertDialog.show();
                break;
            case 500:
                alertDialog.setMessage( "Uh oh, something went wrong! Try logging out and back in again." +
                        " If this error continues, please contact an administrator." );
                alertDialog.show();
                break;
        }


        // Activates the RecycleView for additional options

        myrecyclerview = (RecyclerView) v.findViewById( R.id.group_recyclerview_hue );
        RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter( getContext(), lstGroup );
        myrecyclerview.setLayoutManager( new LinearLayoutManager( getActivity() ) );
        myrecyclerview.setAdapter( recyclerAdapter );


        return v;
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }



    public ArrayList<Group> getHouse(String houseID) {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;


        String fullURL;

        fullURL = sensorServerURL + "GetAllByHouse?id=" + houseID;


        String line;
        StringBuilder result = new StringBuilder();
        ArrayList<Group> arrGroup = new ArrayList<>();
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            // Reads the data send back from the server

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            // Converts data from JSONArray to a user

            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                Group oneGroup = gson.fromJson(jsonArray.getString(i), Group.class);
                arrGroup.add(oneGroup);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return arrGroup;


    }

    public void findDevices(User user) {
        final ArrayList<Group> arrGroup = getHouse(user.getHouseID());


        if (arrGroup.size() > 0) {

            for (int i = 0; i < arrGroup.size(); i++) {
                Group oneGroup = arrGroup.get(i);

                // Groups check
                if (!oneGroup.getgName().matches("Unattached")) {



                    if(!oneGroup.getType().matches("NestGroup")) {

                        all.add( (arrGroup.get( i )).getGroupID() );

                        lstGroup.add( arrGroup.get( i ) );

                    }





                } else {

                    System.out.println("help me");
                }

            }
        }
    }


    public User getUser(String username, String password)
    {
        code = 0;
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ "username="+username+"&&password="+password;

        String line;
        StringBuilder result = new StringBuilder();
        User oneUser = null;

        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            // Reads the data send back from the server

            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            // Sets "code" to be the HTTP response code.

            code = conn.getResponseCode();

            // Converts data from JSONArray to a user

            JSONArray jsonArray = new JSONArray(result.toString());


            for (int i = 0; i < jsonArray.length(); i++) {
                Gson gson = new Gson();
                oneUser = gson.fromJson(jsonArray.getString(i), User.class);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;

    }




}



