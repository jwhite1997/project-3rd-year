package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import user.User;

import static com.example.a15077496.lab1.MainActivity.sensorServerURL;


public class FragmentAddGroup extends Fragment {


    User oneUser = null;
    View v;
    private String type;
    private AlertDialog alertDialog;
    private String username;
    private String password;
    private View rootView;
    String[] items = new String[]{"Select a group type", "LightGroup", "NestGroup"};

    //   private ArrayList adapter =new ArrayList<>();

    public FragmentAddGroup() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {

        v = inflater.inflate( R.layout.activity_new_group, container, false );

        Bundle b = getArguments();
        if (b != null) {
            // String username = bundle.getString("username");

            username = b.getString( "username" );
            password = b.getString( "password" );
            System.out.println( "HELLO " + username + password );
        } else {
            System.out.println( b );
        }


        alertDialog = new AlertDialog.Builder( getActivity() ).create();
        alertDialog.setTitle( "Alert" );
        alertDialog.setButton( AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                } );
        rootView = inflater.inflate(R.layout.activity_new_group,container,false);
        Spinner dropdown = (Spinner) rootView.findViewById( R.id.spinner4 );


            /*for(int i=0; i<items.length;i++){

                items.add(items[i]);
            }*/


        System.out.print(items + "ffjfjgjg");
        //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource( this, R.array.group_array,android.R.layout.simple_spinner_dropdown_item);

        dropdown.setAdapter( new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_list_item_1 , items));

        dropdown.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                switch (i) {
                    case 0:
                        break;
                    case 1:
                        type = adapterView.getItemAtPosition( 1 ).toString();
                        break;
                    case 2:
                        type = adapterView.getItemAtPosition( 2 ).toString();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                type = adapterView.getItemAtPosition( 1 ).toString();

            }


        } );
        Button group = (Button) rootView.findViewById( R.id.btnGroup );

        group.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                TextView nameIn = (EditText) rootView.findViewById( R.id.gNameIn );
                String gName = nameIn.getText().toString();
                String houseID = oneUser.getHouseID();

                int code = toServer( gName, type, houseID );

                switch (code) {
                    case 200:

                        alertDialog.setMessage( "Group has been created!" );
                        alertDialog.show();

                        break;
                    case 422:

                        alertDialog.setMessage( "Ensure that a name and type have been selected!" );
                        alertDialog.show();

                        break;
                    case 500:

                        alertDialog.setMessage( "Server error. If this error continues, please" +
                                " contact an administrator" );
                        alertDialog.show();

                        break;
                    case 401:

                        alertDialog.setMessage( "Group already exists!" );
                        alertDialog.show();

                        break;
                    case 404:

                        alertDialog.setMessage( "Server error. If this error continues, please contact" +
                                " an administrator." );
                        alertDialog.show();

                        break;
                }


            }
        } );

        return v;
    }


    public int toServer(String gName, String type, String houseID)
    {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        String serverURL = "http://10.0.2.2:8080/ProjectTesting/NewGroup";

        String fullURL;

        fullURL = serverURL + "?gName=" + gName + "&&type="+type+"&&houseID="+houseID;


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");


        int result = 0;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();


        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;


    }


    public User getUser(String username, String password)
    {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;

        String fullURL;

        fullURL = sensorServerURL + "GetUser?"+ URLEncoder.encode("username="+username+"&&password="+password);

        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");

        String line;
        StringBuilder result = new StringBuilder();


        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");


            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);

            }
            rd.close();

            if(conn.getResponseCode()==200) {
                JSONArray jsonArray = new JSONArray(result.toString());


                for (int i = 0; i < jsonArray.length(); i++) {
                    Gson gson = new Gson();
                    oneUser = gson.fromJson(jsonArray.getString(i), User.class);
                }
            }
            else
            {
                oneUser = null;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return oneUser;

    }
}
