package com.example.a15077496.lab1;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

public class tabs extends AppCompatActivity {


    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        //Add Fragments Here

        adapter.AddFragment(new FragmentHue(),"");
        //adapter.AddFragment(new FragmentNest(),"");
        //adapter.AddFragment(new FragmentBills(),"");
        //adapter.AddFragment(new FragmentNewGroup(),"");
        //viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_hue);
       // tabLayout.getTabAt(1).setIcon(R.drawable.ic_nest);
        //tabLayout.getTabAt(2).setIcon(R.drawable.ic_bill);
        //tabLayout.getTabAt(3).setIcon(R.drawable.ic_add);

        //remove shadow

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);


    }
}