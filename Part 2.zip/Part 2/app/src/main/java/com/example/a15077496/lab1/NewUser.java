package com.example.a15077496.lab1;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class NewUser extends AppCompatActivity {
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newuser);
        StrictMode.ThreadPolicy policy =
                new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Intent intent = getIntent();
        final String house = intent.getStringExtra("house");

        Button register = (Button) findViewById(R.id.btnRegister);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView userIn = (EditText) findViewById(R.id.userIn);
                TextView passIn = (EditText) findViewById(R.id.passIn);

                String username = userIn.getText().toString();
                String password = passIn.getText().toString();

                AlertDialog alertDialog = new AlertDialog.Builder(NewUser.this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                int code = toServer(username, password, house);

                switch(code)
                {
                    case 200:

                        alertDialog.setMessage("User created!");
                        alertDialog.show();

                        break;
                    case 401:

                        alertDialog.setMessage("User already exists");
                        alertDialog.show();

                        break;
                    case 422:

                        alertDialog.setMessage("Please check that username and password are set.");
                        alertDialog.show();

                        break;
                    case 500:

                        alertDialog.setMessage("Server error. If this error continues, please contact" +
                                " an administrator.");
                        alertDialog.show();
                        break;
                    case 404:

                        alertDialog.setMessage("Server error. If this error continues, please contact" +
                                " an administrator.");
                        alertDialog.show();

                        break;

                }


            }
        });




    }
    public int toServer(String username, String password, String house)
    {
        // gDAO.findAllByHouse(user.getHouseID());
        URL url;
        HttpURLConnection conn;
        String serverURL = "http://10.0.2.2:8080/ProjectTesting/NewUser";

        String fullURL;

        fullURL = serverURL + URLEncoder.encode("?username=" + username + "&&password="+password+"&&houseID="+house);


        fullURL = fullURL.replaceAll("%3D", "=")
                .replaceAll("%26", "&")
                // .replaceAll("%5B","[")
                //.replaceAll("%5D","]")
                .replaceAll("%2C", ",");


        int result = 0;
        try {

            url = new URL(fullURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            result = conn.getResponseCode();


        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}