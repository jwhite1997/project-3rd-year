package com.example.a15077496.lab1;

import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;



import group.Group;
import user.User;

public class MainActivity extends AppCompatActivity {


    public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";

    //create clientID
    String clientId = Utils.getMacAddress() + "-sub";

    private String username,password;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    ArrayList<Integer> all = new ArrayList<>();
    User user;

    private MqttClient mqttClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        // Gets username and password from the login
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        password = intent.getStringExtra("password");

        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());


        // Bundles for sending data to fragments
        final Bundle bundle = new Bundle();
        bundle.putString("username", username);
        bundle.putString("password", password);

        FragmentHue fragHue = new FragmentHue();
        adapter.AddFragment(fragHue, "");
        fragHue.setArguments(bundle);


      /* try {
            // change from original. Messages in "null" are not stored
            mqttClient = new MqttClient(BROKER_URL, clientId,null);


            mqttClient.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectionLost(Throwable cause) {
                    //This is called when the connection is lost. We could reconnect here.
                    System.out.print("Connection Lost");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    System.out.println( "Message arrived. Topic: " + topic + "  Message1: " + message.toString() );
                    // get message data and strip of trailing character
                    final String messageStr = message.toString();
                    bundle.putString( "temp", messageStr );
                    // final TextView sensorValueTV = (TextView) findViewById(R.id.sensorValueTV);

                    if (messageStr != null) {

                        runOnUiThread( new Runnable() {
                            public void run() {
                                // Update UI elements
                                //run

                            }
                        } );
                        if ("mmusensor/LWT".equals( topic )) {
                            System.err.println( "Sensor gone!" );
                        }
                    }else if(messageStr == null){
                        System.out.println("no heater found");
                        String failed = "0";

                    }
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    //no-op
                }

                @Override
                public void connectComplete(boolean b , String s) {

                    //no-op
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }


        startSubscribing();*/

        FragmentNest fragNest = new FragmentNest();
        adapter.AddFragment(fragNest,"");
        fragNest.setArguments(bundle);




        FragmentAddGroup fragGroup = new FragmentAddGroup();
        adapter.AddFragment(fragGroup,"");
        fragGroup.setArguments( bundle );


        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_hue);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_nest);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_add);


        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);


    }

    // Overrides the back button from this page. Resetting the login data.
    public void onBackPressed() {
        startActivity(new Intent(this, Login.class));
    }

    public void startSubscribing() {
        try {
            mqttClient.connect();

            //Subscribe to all subtopics of home
            final String topic = "home/hue/temperature";
            mqttClient.subscribe(topic);
            System.out.println("client address" +clientId);
            System.out.println("Subscriber is now listening to "+topic);
            //sensorValueTV.setText("Listening");
            //Restart( Context ctx );

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    // Restart function for this class.
    public void Restart(Context ctx)
    {
        ((MainActivity) ctx).recreate();
    }


}


