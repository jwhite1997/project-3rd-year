package com.example.a15077496.lab1;

import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import group.Group;
import user.User;

public class MainActivity extends AppCompatActivity {



    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    // private Switch SwitchButton;
    ArrayList<Integer> all = new ArrayList<>();
    User user;

    public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";

    //We have to generate a unique Client id.
    String clientId = Utils.getMacAddress() + "-sub";

    private MqttClient mqttClient;



    public static String sensorServerURL = "http://10.0.2.2:8080/ProjectTesting/";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // temp use of ThreadPolicy until use AsyncTask
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);



        Intent intent = getIntent();
        final String username = intent.getStringExtra("username");
        final String password = intent.getStringExtra("password");
        String temp;

        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        int index;

        //bundles for sending data to fragments
        final Bundle bundle = new Bundle();
        bundle.putString("username", username);
        bundle.putString("password", password);


        try {
            // change from original. Messages in "null" are not stored
            mqttClient = new MqttClient(BROKER_URL, clientId,null);


            mqttClient.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectionLost(Throwable cause) {
                    //This is called when the connection is lost. We could reconnect here.
                    System.out.print("Connection Lost");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    System.out.println("Message arrived. Topic: " + topic + "  Message: " + message.toString());
                    // get message data and strip of trailing character
                    final String messageStr = message.toString();

                   // final TextView sensorValueTV = (TextView) findViewById(R.id.sensorValueTV);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            // Update UI elements
                           // sensorValueTV.setText(messageStr);
                            System.out.println("message text: " + messageStr);
                           // FragmentManager FragmentNest.detach();
                            Bundle bundletemp = new Bundle();
                            bundletemp.putString("temp", messageStr );
                            bundle.putString("username", username);
                            bundle.putString("password", password);
                            FragmentNest fragNest = new FragmentNest();
                            adapter.AddFragment(fragNest,"");
                            fragNest.setArguments(bundletemp);

                        }
                    });
                    if ("mmusensor/LWT".equals(topic)) {
                        System.err.println("Sensor gone!");
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    //no-op
                }

                @Override
                public void connectComplete(boolean b , String s) {
                    //no-op
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }


        startSubscribing();





        FragmentHue fragHue = new FragmentHue();
        adapter.AddFragment(fragHue, "");
        fragHue.setArguments(bundle);


        FragmentNest fragNest = new FragmentNest();
        adapter.AddFragment(fragNest,"");
        fragNest.setArguments(bundle);

        //Add Fragments Here
        //adapter.AddFragment(new FragmentBills(),"");
        adapter.AddFragment(new FragmentAddGroup(),"");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_hue);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_nest);
        //tabLayout.getTabAt(2).setIcon(R.drawable.ic_bill);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_add);

        //remove shadow

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);



        Spinner dropdown = (Spinner) findViewById(R.id.spinner);

        String[] items = new String[]{"+", "New User", "New Group"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        dropdown.setAdapter(adapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        break;
                    case 1:

                        Intent myIntent = new Intent(MainActivity.this, NewUser.class);
                        myIntent.putExtra("house", user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                    case 2:

                        myIntent = new Intent(MainActivity.this, NewGroup.class);
                        myIntent.putExtra("house", user.getHouseID());
                        MainActivity.this.startActivity(myIntent);

                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        //}

    }


    public void Restart(Context ctx)
    {
        ((MainActivity) ctx).recreate();
    }


    public void startSubscribing() {
        try {
            mqttClient.connect();

            //Subscribe to all subtopics of home
            final String topic = "home/hue/temperature";
            mqttClient.subscribe(topic);
            System.out.println("client address" +clientId);
            System.out.println("Subscriber is now listening to "+topic);
           System.out.println("Listening");


        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


}


