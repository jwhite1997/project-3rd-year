package nest;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.NestDAO;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/NestServ")
public class NestServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NestServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Gets the remaining parameters from what is entered.
		String access_token = request.getParameter("access_token");
		String client_version = request.getParameter("client_version");
		String device_id = request.getParameter("device_id");
		String locale = request.getParameter("locale");
		String software_version = request.getParameter("software_version");
		String structure_id = request.getParameter("structure_id");
		String name = request.getParameter("name");
		String name_long = request.getParameter("name_long");
		String last_connection = request.getParameter("last_connection");
		String is_online = request.getParameter("is_online");
		String can_cool = request.getParameter("can_cool");
		String can_heat = request.getParameter("can_heat");
		String is_using_emergency_heat = request.getParameter("is_using_emergency_heat");
		String has_fan = request.getParameter("has_fan");
		String fan_timer_active = request.getParameter("fan_timer_active");
		String fan_timer_timeout = request.getParameter("fan_timer_timeout");
		String has_leaf = request.getParameter("has_leaf");
		String temperature_scale = request.getParameter("temperature_scale");
		String target_temperature_f = request.getParameter("target_temperature_f");
		String target_temperature_c = request.getParameter("target_temperature_c");
		String target_temperature_high_f = request.getParameter("target_temperature_high_f");
		String target_temperature_high_c = request.getParameter("target_temperature_high_c");
		String target_temperature_low_f = request.getParameter("target_temperature_low_f");
		String target_temperature_low_c = request.getParameter("target_temperature_low_c");
		String eco_temperature_high_f = request.getParameter("eco_temperature_high_f");
		String eco_temperature_high_c = request.getParameter("eco_temperature_high_c");
		String eco_temperature_low_f = request.getParameter("eco_temperature_low_f");
		String eco_temperature_low_c = request.getParameter("eco_temperature_low_c");
		String away_temperature_high_f = request.getParameter("away_temperature_high_f");
		String away_temperature_high_c = request.getParameter("away_temperature_high_c");
		String away_temperature_low_f = request.getParameter("away_temperature_low_f");
		String away_temperature_low_c = request.getParameter("away_temperature_low_c");
		String hvac_mode = request.getParameter("hvac_mode");
		String previous_hvac_mode = request.getParameter("previous_hvac_mode");
		String ambient_temperature_f = request.getParameter("ambient_temperature_f");
		String ambient_temperature_c = request.getParameter("ambient_temperature_c");
		String humidity = request.getParameter("humidity");
		String hvac_state = request.getParameter("hvac_state");
		String where_id = request.getParameter("where_id");
		String is_locked = request.getParameter("is_locked");
		String locked_temp_min_f = request.getParameter("locked_temp_min_f");
		String locked_temp_min_c = request.getParameter("locked_temp_min_c");
		String locked_temp_max_f = request.getParameter("locked_temp_max_f");
		String locked_temp_max_c = request.getParameter("locked_temp_max_c");
		String label = request.getParameter("label");
		String where_name = request.getParameter("where_name");
		String sunlight_correction_enabled = request.getParameter("sunlight_correction_enabled");
		String sunlight_correction_active = request.getParameter("sunlight_correction_active");
		String fan_timer_duration = request.getParameter("fan_timer_duration");
		String time_to_target = request.getParameter("time_to_target");
		String time_to_target_training = request.getParameter("time_to_target_training");
		String thermostats = request.getParameter("thermostats");
		String away = request.getParameter("away");
		String sName = request.getParameter("sName");
		String country_code = request.getParameter("country_code");
		String peak_period_start_time = request.getParameter("peak_period_start_time");
		String peak_period_end_time = request.getParameter("peak_period_end_time");
		String time_zone = request.getParameter("time_zone");
		String wName = request.getParameter("wName");
		
		
		
		
		
		NestConstr nest = new NestConstr(access_token,  client_version, device_id,  locale, software_version, structure_id,
				 name, name_long, last_connection, is_online, can_cool,
				 can_heat, is_using_emergency_heat, has_fan, fan_timer_active,
				 fan_timer_timeout, has_leaf,temperature_scale, target_temperature_f,
				 target_temperature_c, target_temperature_high_f, target_temperature_high_c,
				 target_temperature_low_f, target_temperature_low_c, eco_temperature_low_f,
				 eco_temperature_low_c, eco_temperature_high_f, eco_temperature_high_c,
				 away_temperature_low_f, away_temperature_low_c, away_temperature_high_f,
				 away_temperature_high_c, hvac_mode, previous_hvac_mode,
				 ambient_temperature_f, ambient_temperature_c, humidity, hvac_state,
				 where_id, is_locked, locked_temp_min_f, locked_temp_min_c,
				 locked_temp_max_f, locked_temp_max_c, label, where_name,
				 sunlight_correction_enabled, sunlight_correction_active, fan_timer_duration,
				 time_to_target, time_to_target_training,  thermostats,  away,  sName,  country_code,
				 peak_period_start_time, peak_period_end_time, time_zone,  wName);
	
		if(access_token == null)
		{
			System.out.print("Waiting for valid entries.");
		}
		else
		{
			nest.toString();
			PrintWriter out = response.getWriter();
		
			out.print(nest);
			System.out.println("Hello?");
			System.out.println(nest);
			
			NestDAO dao = new NestDAO();
			
			dao.insertNest(nest);
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
