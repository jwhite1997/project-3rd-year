package lights;

public class State {

	private static String on;
	private static String bri;
	private static String hue;
	private static String sat;
	private static String xy;
	private static String ct;
	private static String alert;
	private static String effect;
	private static String colormode;
	private static String reachable;
	
	public State()
	{
		this.on = "false";
		this.bri = "0";
		this.hue = "0";
		this.sat = "0";
		this.xy = "default";
		this.ct = "0";
		this.alert = "default";
		this.effect = "default";
		this.colormode = "default";
		this.reachable = "false";
	}
	
	public State(String on, String bri, String hue, String sat, String xy, String ct, 
			String alert, String effect, String colormode, String reachable)
	{
		this.on = on;
		this.bri = bri;
		this.hue = hue;
		this.sat = sat;
		this.xy = xy;
		this.ct = ct;
		this.alert = alert;
		this.effect = effect;
		this.colormode = colormode;
		this.reachable = reachable;
	}

	public String getOn() {
		return on;
	}

	public void setOn(String on) {
		this.on = on;
	}

	public String getBri() {
		return bri;
	}

	public void setBri(String bri) {
		this.bri = bri;
	}

	public String getHue() {
		return hue;
	}

	public void setHue(String hue) {
		this.hue = hue;
	}

	public String getSat() {
		return sat;
	}

	public void setSat(String sat) {
		this.sat = sat;
	}

	public String getXy() {
		return xy;
	}

	public void setXy(String xy) {
		this.xy = xy;
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public String getEffect() {
		return effect;
	}

	public void setEffect(String effect) {
		this.effect = effect;
	}

	public String getColormode() {
		return colormode;
	}

	public void setColormode(String colormode) {
		this.colormode = colormode;
	}

	public String getReachable() {
		return reachable;
	}

	public void setReachable(String reachable) {
		this.reachable = reachable;
	}
}
