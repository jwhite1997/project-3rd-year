package mqtt.subscriber;

import org.eclipse.paho.client.mqttv3.*;

import mqtt.utils.Utils;


public class MotorSubscribeCallback implements MqttCallback {

    @Override
    public void connectionLost(Throwable cause) {
        //This is called when the connection is lost. We could reconnect here.
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println("Message arrived. Topic: " + topic + "  Message: " + message.toString());
        /*// get message data and strip of trailing character
        String messageStr = message.toString();
        messageStr = messageStr.substring(0,messageStr.length()-1);

        int sensorValue = Integer.parseInt(messageStr);
        // scale sensor to 0-220 range for motor
        int motorPosition = (sensorValue*220 / 1000);
        // now move motor to motor position
*/        
        
        PhidgetMotorMover.moveServoTo(180);
        Utils.waitFor(5);
        PhidgetMotorMover.moveServoTo(0);
        
        if ("home/LWT".equals(topic)) {
            System.err.println("Sensor gone!");
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        //no-op
    }
}
